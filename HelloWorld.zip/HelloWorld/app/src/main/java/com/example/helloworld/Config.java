package com.example.helloworld;

public class Config {
    public static String EMAIL ="your-gmail-username";
    public static String PASSWORD ="your-gmail-password";
}
